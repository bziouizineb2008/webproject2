let locationNameDefault = 'morocco';

// 1. إصلاح: تحديد عناصر الإدخال والاستمارة بدقة من الـ HTML
const form = document.querySelector('#search');
const searchInput = document.querySelector('#city-input');

// 2. تحديد عناصر عرض البيانات داخل الواجهة
const temperature = document.querySelector('.temp p');
const locationName = document.querySelector('.time-location p:nth-child(1)');
const locationTime = document.querySelector('.time-location p:nth-child(2)');
const locationCondition = document.querySelector('.condition p');
const locationIcon = document.querySelector('.weather-icon'); // تم ربطها بصورة الطقس

form.addEventListener('submit', searchForLocation);

const fetchResults = async (location) => {
    // تم إزالة الفراغ الزائد بعد الـ key في الرابط لتجنب مشاكل الإرسال
    let url = 'http://api.weatherapi.com/v1/current.json?key=c96e2dd64f194e4c8db151948262206&q=' + location + '&aqi=no';

    try {
        const res = await fetch(url);
        const data = await res.json();
        
        // تشغيل دالة التحديث وتمرير البيانات المستلمة لها
        updateData(data.current.temp_c, data.location.localtime, data.current.condition.text, data.current.condition.icon);
        console.log(data);
    } catch (error) {
        console.error("حدث خطأ أثناء جلب البيانات:", error);
    }
}

function updateData(temp, time, condition, icon) {
    // تحديث النصوص والصور داخل واجهة المستخدم بالمعلومات الحية
    temperature.textContent = temp + "°C";
    locationTime.textContent = time;
    locationCondition.textContent = condition;
    
    // إضافة "https:" قبل رابط الأيقونة لأن روابط WeatherAPI تأتي بدونه أحياناً
    locationIcon.src = 'https:' + icon; 
}

function searchForLocation(e) {
    e.preventDefault();
    
    const targetLocation = searchInput.value;
    if (targetLocation.trim() !== "") {
        fetchResults(targetLocation);
    }
}

// تشغيل التطبيق لأول مرة بالموقع الافتراضي
fetchResults(locationNameDefault);