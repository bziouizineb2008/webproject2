// 1. Grab the elements from your HTML
let bulbTop = document.querySelector('.bulb');
let bulbBottom = document.querySelector('.bulb-bottom');
let switchButton = document.querySelector('.button');

// 2. Create the function that toggles the light
function toggleLamp() {
    // This adds 'lit' if it's missing, and removes it if it's there!
    bulbTop.classList.toggle('lit');
    bulbBottom.classList.toggle('lit');
    
    // This toggles your switch button style that you already made in CSS
    switchButton.classList.toggle('on'); 
}

// 3. Listen for the click on the switch button
switchButton.addEventListener('click', toggleLamp);